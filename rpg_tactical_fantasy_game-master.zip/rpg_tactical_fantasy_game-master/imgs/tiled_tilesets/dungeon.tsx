<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="spritesheet" tilewidth="32" tileheight="32" tilecount="6080" columns="64">
 <grid orientation="orthogonal" width="48" height="48"/>
 <image source="dungeon.png" width="2048" height="3040"/>
 <tile id="0" type="void"/>
</tileset>
