<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="houses" tilewidth="32" tileheight="32" tilecount="108" columns="6">
 <grid orientation="orthogonal" width="48" height="48"/>
 <image source="houses.png" width="192" height="576"/>
</tileset>
